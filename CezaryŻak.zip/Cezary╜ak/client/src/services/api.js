import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8080', // Zmień na odpowiedni adres serwera
});

export default api;
