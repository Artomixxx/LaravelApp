import styles from "./styles.module.css";
import { useState, useEffect } from "react";
import axios from "axios";
import BookList from "../Books/BookList";
import AddBook from "../Books/AddBook";
import EditBook from "../Books/EditBook";

const Main = () => {
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editBookId, setEditBookId] = useState(null);
  const [books, setBooks] = useState([]);

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/books");
      setBooks(response.data.books);
    } catch (error) {
      console.log(error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    window.location.reload();
  };

  const handleAddBook = () => {
    setIsAdding(true);
    setIsEditing(false);
  };

  const handleEditBook = (bookId) => {
    setEditBookId(bookId);
    setIsAdding(false);
    setIsEditing(true);
  };

  const handleDeleteBook = async (bookId) => {
    try {
      const token = localStorage.getItem("token");
    await axios.delete(`http://localhost:8080/api/books/${bookId}`, {
      headers: { "x-access-token": token },
    });
      fetchBooks();
    } catch (error) {
      console.log(error);
    }
  };

  const handleCancel = () => {
    setIsAdding(false);
    setIsEditing(false);
    setEditBookId(null);
  };

  return (
    <div className={styles.main_container}>
      <nav className={styles.navbar}>
        <button className={styles.white_btn} onClick={handleLogout}>
          Logout
        </button>
      </nav>
      <div>
        {isAdding && <AddBook onCancel={handleCancel} />}
        {isEditing && <EditBook match={{ params: { id: editBookId } }} />}
        {!isAdding && !isEditing && (
          <>
            <BookList
              books={books}
              onEditBook={handleEditBook}
              onDeleteBook={handleDeleteBook}
            />
            <button className={styles.green_btn} onClick={handleAddBook} >Dodaj ksiazke</button>
          </>
        )}
      </div>
    </div>
  );
};

export default Main;
