import React from 'react';
import styles from "./styles.module.css";

const BookList = ({ books, onEditBook, onDeleteBook }) => {
  return (
    <div className={styles.book_list_container}>
      <h2>Lista książek</h2>
      {Array.isArray(books) && books.length > 0 ? (
        <ul>
          {books.map((book) => (
            <li key={book._id} className={styles.book_item}>
              <span className={styles.label}>Tytuł: </span>
              <span className={styles.book_title}>{book.title}</span>
              <span className={styles.label}>Autor: </span>
              <span className={styles.book_author}>{book.author}</span>
              {"   "} {/* Dodany odstęp */}
              <button className={styles.green_btn} onClick={() => onEditBook(book._id)}>Edytuj</button>
              {"   "} {/* Dodany odstęp */}
              <button className={styles.green_btn} onClick={() => onDeleteBook(book._id)}>Usuń</button>
            </li>
          ))}
        </ul>
      ) : (
        <p>Brak książek do wyświetlenia</p>
      )}
    </div>
  );
};

export default BookList;
