import React, { useState, useEffect } from 'react';
import axios from '../../services/api';
import styles from "./styles.module.css";

const EditBook = ({ match }) => {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [authorError, setAuthorError] = useState('');
  const [existingBooks, setExistingBooks] = useState([]);

  useEffect(() => {
    const fetchBook = async () => {
      try {
        const token = localStorage.getItem('token');
        const headers = { "x-access-token": token };

        const response = await axios.get(`/api/books/${match.params.id}`, { headers });
        const book = response.data.book;
        setTitle(book.title);
        setAuthor(book.author);
      } catch (error) {
        console.error(error);
      }
    };

    fetchBook();
  }, [match.params.id]);

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const response = await axios.get('/api/books');
        setExistingBooks(response.data.books);
      } catch (error) {
        console.error(error);
      }
    };

    fetchBooks();
  }, []);

  const handleEditBook = async () => {
    // Walidacja pola "author"
    if (!validateAuthor(author)) {
      setAuthorError('Author must contain at least one alphanumeric character');
      return;
    }

    const existingBook = existingBooks.find(
      book =>
        book.id !== match.params.id &&
        book.title.toLowerCase() === title.toLowerCase() &&
        book.author.toLowerCase() === author.toLowerCase()
    );

    if (existingBook) {
      setAuthorError('A book with the same title and author already exists.');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const headers = { "x-access-token": token };

      const response = await axios.put(`/api/books/${match.params.id}`, { title, author }, { headers });
      console.log(response.data);
      window.location.href = 'http://localhost:3000/';
    } catch (error) {
      console.error(error);
    }
  };

  const validateAuthor = (author) => {
    const pattern = /^(?=.*[a-zA-Z0-9]).+$/; // Przynajmniej jeden alfanumeryczny znak
    return pattern.test(author);
  };

  return (
    <div className={styles.edit_book_container}>
      <h1>Edit Book</h1>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Title"
        className={styles.edit_book_input}
      />
      <input
        type="text"
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
        placeholder="Author"
        className={styles.edit_book_input}
      />
      {authorError && <p className={styles.error_message}>{authorError}</p>}
      <button onClick={handleEditBook} className={styles.edit_book_btn}>
        Save Changes
      </button>
    </div>
  );
};

export default EditBook;
