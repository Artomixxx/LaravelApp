import React, { useState, useEffect } from 'react';
import axios from '../../services/api';
import styles from "./styles.module.css";

const AddBook = ({ onCancel }) => {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [authorError, setAuthorError] = useState('');
  const [existingBooks, setExistingBooks] = useState([]);
  const [addBookSuccess, setAddBookSuccess] = useState(false);

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const response = await axios.get('/api/books');
        setExistingBooks(response.data.books);
      } catch (error) {
        console.error(error);
      }
    };

    fetchBooks();
  }, []);

  const handleAddBook = async () => {
    if (!validateAuthor(author)) {
      setAuthorError('Author must contain at least one alphanumeric character');
      return;
    }

    const existingBook = existingBooks.find(
      book => book.title.toLowerCase() === title.toLowerCase() && book.author.toLowerCase() === author.toLowerCase()
    );

    if (existingBook) {
      setAuthorError('A book with the same title and author already exists.');
      return;
    }

    try {
      const token = localStorage.getItem('token'); // Pobierz token
      await axios.post('/api/books', { title, author }, { headers: { "x-access-token": token } });
      console.log(response.data);
      setAddBookSuccess(true); // Ustaw stan sukcesu dodania książki
    } catch (error) {
      console.error(error);
    }
  };

  const validateAuthor = (author) => {
    const pattern = /^(?=.*[a-zA-Z0-9]).+$/; // Przynajmniej jeden alfanumeryczny znak
    return pattern.test(author);
  };

  if (addBookSuccess) {
    return (
      <div className={styles.add_book_container}>
        <h1>Book added successfully!</h1>
        <button onClick={() => setAddBookSuccess(false)} className={styles.add_book_btn}>
          Add Another Book
        </button>
        <button onClick={onCancel} className={styles.add_book_btn}>
          Cancel
        </button>
      </div>
    );
  }

  return (
    <div className={styles.add_book_container}>
      <h1>Add Book</h1>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Title"
        className={styles.add_book_input}
      />
      <input
        type="text"
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
        placeholder="Author"
        className={styles.add_book_input}
      />
      {authorError && <p className={styles.error_message}>{authorError}</p>}
      <button onClick={handleAddBook} className={styles.add_book_btn}>
        Add Book
      </button>
      <button onClick={onCancel} className={styles.add_book_btn}>
        Cancel
      </button>
    </div>
  );
};

export default AddBook;
