const express = require('express');
const router = express.Router();
const Book = require('../models/book');
const bcrypt = require("bcrypt");
const tokenVerification = require('../middleware/tokenVerification'); // Importuj middleware tokenVerification

// Kontroler dodawania książki
router.post('/', tokenVerification, async (req, res) => {
  try {
    const { title, author } = req.body;

    // Sprawdź, czy istnieje już książka o takim samym tytule i autorze
    const existingBook = await Book.findOne({ title, author });
    if (existingBook) {
      return res.status(400).json({ success: false, message: 'Książka o podanym tytule i autorze już istnieje' });
    }

    // Utwórz nową książkę
    const book = new Book({ title, author });
    await book.save();

    res.json({ success: true, book });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Błąd dodawania książki' });
  }
});

// Kontroler wyświetlania książek
router.get('/', async (req, res) => {
  try {
    // Pobierz wszystkie książki
    const books = await Book.find();

    res.json({ success: true, books });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Błąd pobierania książek' });
  }
});

// Kontroler usuwania książki
router.delete('/:id', tokenVerification, async (req, res) => {
  try {
    const { id } = req.params;
    // Sprawdź, czy książka istnieje
    const book = await Book.findOne({ _id: id })
    if (!book) {
      return res.status(404).json({ success: false, message: 'Książka nie znaleziona' })
    }
    
    // Usuń książkę
    await Book.findByIdAndRemove(id)

    res.json({ success: true, message: 'Książka usunięta' })
  } catch (error) {
    res.status(500).json({ success: false, message: 'Błąd usuwania książki' })
  }
});



// Kontroler edycji książki
router.put('/:id', tokenVerification, async (req, res) => {
  try {
    const { id } = req.params;
    const { title, author } = req.body;

    // Sprawdź, czy książka istnieje
    const book = await Book.findOne({ _id: id });
    if (!book) {
      return res.status(404).json({ success: false, message: 'Książka nie znaleziona' });
    }

    // Sprawdź, czy istnieje inna książka o takim samym tytule i autorze
    const existingBook = await Book.findOne({ title, author });
    if (existingBook && existingBook._id.toString() !== id) {
      return res.status(400).json({ success: false, message: 'Książka o podanym tytule i autorze już istnieje' });
    }

    // Zaktualizuj tytuł i autora książki
    book.title = title;
    book.author = author;
    await book.save();

    res.json({ success: true, book });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Błąd aktualizacji książki' });
  }
});
  

module.exports = router;
