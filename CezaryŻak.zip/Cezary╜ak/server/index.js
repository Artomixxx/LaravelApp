require('dotenv').config();
const express = require('express');
const app = express();
const cors = require('cors');
const morgan = require('morgan');
const fs = require('fs');
const path = require('path');

// Konfiguracja morgan dla logowania żądań HTTP
const accessLogStream = fs.createWriteStream(path.join(__dirname, 'access.log'), { flags: 'a' });
app.use(morgan('combined', { stream: accessLogStream }));

// Middleware
app.use(express.json());
app.use(cors());
const tokenVerification = require('./middleware/tokenVerification');

// Routes
const userRoutes = require("./routes/users");
const authRoutes = require("./routes/auth");
const booksRoutes = require('./routes/books');

app.use("/api/users", userRoutes);
app.use("/api/auth", authRoutes);
app.use('/api/books', booksRoutes);

const connection = require('./db');
connection();

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Nasłuchiwanie na porcie ${port}`));
